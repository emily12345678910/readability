#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

float count_letters(string text);
float count_words(string text);
float count_sentences(string text);

int main(void)
{
    // Promp user for text
    string text = get_string("Text: ");

    // Value needed for index
    int letters = count_letters(text);
    int words = count_words(text);
    int sentences = count_sentences(text);

    // Compute for grade
    float L = 100 * (float) letters / (float) words;
    float S = 100 * (float) sentences / (float) words;
    float grade = 0.0588 * (float) L - 0.296 * (float) S - 15.8;
    
    // Print Grade
    if ((int)round(grade) <= 16 && (int)round(grade) > 0)
    {
        printf("Grade %i\n", (int)round(grade));
    }
    else if ((int)round(grade) > 16)
    {
        printf("Grade 16+\n");
    }
    else
    {
        printf("Before Grade 1\n");
    }
}

// Count the letters in the string
float count_letters(string text)
{
    float letters = 0;
    for (int i = 0, n = strlen(text); i < n; i++)
    {
        if (isalpha(text[i]))
        {
            letters++;
        }
    }
    return letters;
}

// Count words in the string
float count_words(string text)
{
    float words = 1;
    for (int i = 0, n = strlen(text); i < n; i++)
    {
        if (isspace(text[i]))
        {
            words++;
        }
    }
    return words;
}

// Count sentences in the string
float count_sentences(string text)
{
    float sentences = 0;
    for (int i = 0, n = strlen(text); i < n; i++)
    {
        if (text[i] == '!')
        {
            sentences++;
        }
        else if (text[i] == '?')
        {
            sentences++;
        }
        else if (text[i] == '.')
        {
            sentences++;
        }
    }
    return sentences;
}
